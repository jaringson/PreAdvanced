#include <iostream>

using namespace std;

int main()

{

	cout << "\t\t\t\t Basic BYU Trivia \n\n";

	cout << "\t Questions \t\t\t\t\t Answers \n\n";

	cout << "What was the original name of BYU? \t\t Brigham Young Academy \n";

	cout << "When was BYA established? \t\t\t 1875 \n";

	cout << "Who was the first \"permanent\" principle of BYA?\t Karl Maeser \n";

	cout << "When did BYA become BYU? \t\t\t 1903 \n";

	cout << "To what sports conference do we belong? \t West Coast Conference \n";

	cout << "When did BYU win the national football title? \t 1984 \n";

	cout << "Who won the Heisman Trophy in 1990? \t\t Ty Detmer \n\n\n";

	system("pause");

	return 0;

}
