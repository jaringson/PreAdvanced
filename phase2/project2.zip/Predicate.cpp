#include "Predicate.h"


Predicate::Predicate(string n, vector<Parameter> vec)
{
	name = n;
	predicate_data = vec;
}
Predicate::Predicate()
{

}


Predicate::~Predicate()
{
}
