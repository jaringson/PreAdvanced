#include "Parameter.h"


Parameter::Parameter(bool x, string val)
{
	isString = x;
	value = val;
}


Parameter::~Parameter()
{
}
