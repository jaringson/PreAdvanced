#include "Database.h"


Database::Database()
{
	//database[name] = relation;
}


Database::~Database()
{
}
