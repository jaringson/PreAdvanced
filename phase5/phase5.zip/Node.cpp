#include "Node.h"


Node::Node()
{
	visited = false;
}


Node::~Node()
{
}
